Framework7.prototype.plugins.joe = function (app, params) {
    if (!params) return;
	var $$ = Dom7;
		var math = function(){
				"use strict";
			return {
	        mean: function(nums){
		 		var y = 0;
		 		$.each(nums,function(a,b){
		 			y = y + b;
		 		});
		 		return y/nums.length;
	        },
	        median: function(nums) {
                var median = 0,
                numsLen = nums.length;
                if (numsLen % 2 ===0) {
                    median = (nums[numsLen / 2 - 1] + nums[numsLen / 2]) / 2;
                }
                else {
                    median = nums[(numsLen - 1) / 2];
                }
                return median;
                },
          mode: function(x) {
                var counter = 1,repeated = 1,arrMode=[],elemNumber = 0,i;
                for (i=1;i<x.length ; i++)
                {
                if (x[i]==x[i-1]){
                counter++;
                if (counter>repeated) {
                repeated = counter;
                elemNumber = 0;
                arrMode = [];
                arrMode[elemNumber] = x[i]
                }
                else{
                if(counter==repeated && counter>1)   {
                elemNumber++;
                arrMode[elemNumber] = x[i];
                }
              }
            }
                else{
                counter = 1;
                    }
                }
                  if (arrMode.length >0){
                return arrMode;
              }
                return "{No Mode}"
            },
}
	}();
    return {
        hooks: {
            appInit: function () {
	        	$$("#btnClick").on("click",function(){
	        		var input = $$("#inputHere").val().split(",");
	        		$.each(input,function(a,b){
	        			input[a]=parseInt(input[a]);
	        		});
	        		input.sort(function(a,b){return a-b});
	        		console.log("Sorting: "+ input);
	        		console.log("mean:    "+ math.mean(input));
	        		console.log("median:  "+ math.median(input));
	        		console.log("mode: "+ math.mode(input));

	        		$$("#A").html("DATA: "+"["+input+"]");
	        		$$("#B").html("MEAN:    "+ math.mean(input));
	        		$$("#C").html("MEDIAN:  "+ math.median(input));
	        		$$("#D").html("MODE:    "+ math.mode(input));
	        	});
	        }
        }
   	 };
    };

var app = new Framework7({
    joe: true,
    material: true
});
var $$ = Dom7;